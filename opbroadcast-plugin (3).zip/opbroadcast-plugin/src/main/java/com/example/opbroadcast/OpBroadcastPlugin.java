package com.example.opbroadcast;

import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import de.maxhenkel.voicechat.api.BukkitVoicechatService;

public final class OpBroadcastPlugin extends JavaPlugin {

    private VoiceBroadcastHandler voiceHandler; // null if Simple Voice Chat isn't present

    private boolean chatFrozen = false;
    private BukkitTask freezeTimeoutTask;   // used by the timed /broadcast freeze
    private BukkitTask titleRefreshTask;    // used to keep the voice-broadcast title on screen indefinitely

    @Override
    public void onEnable() {
        saveDefaultConfig();

        BroadcastCommand executor = new BroadcastCommand(this);
        var broadcastCmd = getCommand("broadcast");
        if (broadcastCmd != null) broadcastCmd.setExecutor(executor);

        var vbCmd = getCommand("vbroadcast");
        if (vbCmd != null) vbCmd.setExecutor(executor);

        Bukkit.getPluginManager().registerEvents(new ChatFreezeListener(this), this);

        tryHookVoicechat();

        getLogger().info("OpBroadcast enabled. Voice broadcast available: " + (voiceHandler != null));
    }

    // ---------------------------------------------------------------
    // Chat freeze state
    // ---------------------------------------------------------------

    public boolean isChatFrozen() {
        return chatFrozen;
    }

    /** Freezes chat for a fixed number of seconds, then auto-unfreezes. Used by /broadcast. */
    public void freezeChatFor(int seconds) {
        chatFrozen = true;
        if (freezeTimeoutTask != null) freezeTimeoutTask.cancel();
        freezeTimeoutTask = Bukkit.getScheduler().runTaskLater(this, () -> {
            chatFrozen = false;
            freezeTimeoutTask = null;
        }, seconds * 20L);
    }

    /** Freezes chat with no auto-expiry. Used while voice broadcast is toggled on. */
    public void freezeChatIndefinitely() {
        chatFrozen = true;
        if (freezeTimeoutTask != null) {
            freezeTimeoutTask.cancel();
            freezeTimeoutTask = null;
        }
    }

    public void unfreezeChat() {
        chatFrozen = false;
        if (freezeTimeoutTask != null) {
            freezeTimeoutTask.cancel();
            freezeTimeoutTask = null;
        }
    }

    // ---------------------------------------------------------------
    // On-screen title helpers
    // ---------------------------------------------------------------

    /** Shows a title/subtitle to every online player once, using configured fade/stay timings. */
    public void showTitleToAll(String title, String subtitle) {
        int fadeIn = getConfig().getInt("options.title-fade-in", 10);
        int stay = getConfig().getInt("options.title-stay", 100);
        int fadeOut = getConfig().getInt("options.title-fade-out", 20);
        for (var player : Bukkit.getOnlinePlayers()) {
            player.sendTitle(title, subtitle, fadeIn, stay, fadeOut);
        }
    }

    /**
     * Keeps a title on every screen indefinitely by re-sending it periodically
     * (titles fade on their own otherwise). Used while voice broadcast is on.
     */
    public void startPersistentTitle(String title, String subtitle) {
        stopPersistentTitle();
        int stay = getConfig().getInt("options.title-stay", 100);
        long refreshInterval = Math.max(20L, stay - 10L); // refresh just before it would fade
        titleRefreshTask = Bukkit.getScheduler().runTaskTimer(this,
                () -> showTitleToAll(title, subtitle), 0L, refreshInterval);
    }

    public void stopPersistentTitle() {
        if (titleRefreshTask != null) {
            titleRefreshTask.cancel();
            titleRefreshTask = null;
        }
        for (var player : Bukkit.getOnlinePlayers()) {
            player.resetTitle();
        }
    }

    // ---------------------------------------------------------------
    // Simple Voice Chat hookup
    // ---------------------------------------------------------------

    /**
     * Simple Voice Chat exposes itself as a Bukkit service (BukkitVoicechatService)
     * that other plugins register against. If the "voicechat" plugin isn't installed
     * or hasn't registered that service yet, this just silently skips the voice
     * feature — /broadcast (text) still works either way.
     */
    private void tryHookVoicechat() {
        Plugin vc = Bukkit.getPluginManager().getPlugin("voicechat");
        if (vc == null || !vc.isEnabled()) {
            getLogger().info("Simple Voice Chat not found — voice broadcast disabled, text /broadcast still works.");
            return;
        }
        try {
            var provider = Bukkit.getServicesManager().getRegistration(BukkitVoicechatService.class);
            if (provider == null) {
                getLogger().warning("Simple Voice Chat is installed but its service wasn't ready yet — voice broadcast disabled.");
                return;
            }
            BukkitVoicechatService service = provider.getProvider();
            voiceHandler = new VoiceBroadcastHandler(this);
            service.registerPlugin(voiceHandler);
            getLogger().info("Hooked into Simple Voice Chat successfully.");
        } catch (Throwable t) {
            getLogger().warning("Failed to hook into Simple Voice Chat (voice broadcast disabled): " + t);
        }
    }

    public VoiceBroadcastHandler getVoiceHandler() {
        return voiceHandler;
    }
}
